package com.eComplaint;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EComplaintApplicationTests {

	@Test
	void contextLoads() {
	}

}
